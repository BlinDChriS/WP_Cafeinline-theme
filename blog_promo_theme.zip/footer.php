<?php

?>
	

<footer class="container-fluid">
    <div class="container">
        <div class="row">

            <div class="col-md-4 col-xs-12">
            <a href="<?php echo get_permalink(20) ;?>">Café Inline Promo - Blog</a><br>
                <a href="<?php echo get_permalink(30) ;?>">Christian Anis, Ghislain Billard, Marie-Ange Remy</a>
            </div>
                        
            <div class="col-md-5 col-xs-12">
                <a href="https://www.accesscodeschool.fr/" target="blank"><img src="http://localhost/wordpress/wp-content/uploads/2019/02/acs.png" alt="Access Code School"></a>
</div>

            <div class="col-md-3 col-xs-12">
                    <a href="https://www.linkedin.com/company/access-code-school/about/"><i class="fa fa-linkedin" aria-hidden="true"></a></i>
                    <a href="https://twitter.com/accesscodeofp" target="blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href="https://www.facebook.com/AccessCodeSchool/" target="blank"><i class="fa fa-facebook" aria-hidden="true"></i></a><br>
                <a href="<?php echo get_permalink(28) ;?>">Mentions légales</a>
            </div>
</div>
    </div>
</footer>
		

<?php wp_footer(); ?>
</body>
</html>