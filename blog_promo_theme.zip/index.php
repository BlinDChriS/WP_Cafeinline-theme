<?php
/*Template Name: Accueil*/
get_header(); ?>


	<main></main>


<?php get_footer(); ?>
